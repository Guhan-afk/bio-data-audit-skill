# Bio Data Audit Skill 功能介绍

`bio-data-audit` 是一个面向生物数据、食品发酵数据、代谢组学、GC-MS、LC-MS、Excel/CSV 表格分析的 Codex skill。它的核心目标不是让 AI 的内部推理过程变得透明，而是让每一次数据处理都留下外部可审计证据：用了哪些原始文件、数据有多少行多少列、过滤了什么、归一化怎么做、统计阈值是什么、图表来自哪个中间表、最终生成了哪些结果，以及还有哪些潜在风险。

## 适合场景

- 生物实验数据整理和清洗
- 食品发酵实验数据分析
- 代谢组学峰表初步检查
- GC-MS、LC-MS 表格数据处理
- Excel、CSV、TSV 数据分析
- 缺失值、重复值、异常列检查
- 差异分析、归一化、转换、统计检验的过程留痕
- 生成图表后追踪每张图的数据来源和脚本来源
- 为论文、汇报或组会准备可复核的数据处理说明

## 主要功能

1. 保护原始数据  
   默认要求不覆盖 `data/raw/` 下的原始数据，所有处理结果必须另存到 `results/`、`figures/`、`reports/` 或 `audit/`。

2. 自动生成分析计划  
   在正式分析前生成 `audit/analysis_plan.md`，记录任务目标、输入文件、预期输出、主要步骤和关键假设。

3. 生成处理日志  
   在 `audit/processing_log.md` 中记录每一步做了什么、用了什么参数、输入输出文件是什么、处理前后数据规模如何变化。

4. 自动表格基础自检  
   内置 `basic_table_audit.py`，可自动检查 CSV、TSV、TXT、XLSX、XLS 文件，包括文件哈希、行列数、列名、数值列、非数值列、缺失值、重复行、常量列和高缺失列。

5. 记录代谢组和组学分析关键参数  
   要求记录缺失值阈值、填补方法、归一化方法、log 转换、统计检验、多重检验校正、Fold change 计算方式、差异筛选标准、样品分组匹配情况和 QC 样本使用情况。

6. 追踪图表来源  
   每张图都需要说明来源数据表、生成脚本、主要绘图参数、标签和图例是否清楚，以及是否存在过度解释风险。

7. 输出中文自检报告  
   最终生成 `audit/self_check_report.md`，用研究人员能看懂的语言说明本次分析做了什么、用了哪些数据、输出了哪些文件、哪里可能有风险。

## 使用方法

把整个 `bio-data-audit` 文件夹放到项目的 `.agents/skills/` 目录下：

```text
你的项目/
└── .agents/
    └── skills/
        └── bio-data-audit/
            ├── SKILL.md
            ├── agents/
            │   └── openai.yaml
            └── scripts/
                └── basic_table_audit.py
```

然后在 Codex 中这样调用：

```text
请使用 $bio-data-audit 分析 data/raw/xxx.xlsx 和 data/metadata/group.xlsx。
要求：不要覆盖原始数据，结果输出到 results/，图片输出到 figures/，最后生成 audit/self_check_report.md。
```

## 推荐项目结构

```text
项目/
├── data/
│   ├── raw/
│   └── metadata/
├── scripts/
├── results/
├── figures/
├── reports/
├── audit/
└── .agents/
    └── skills/
        └── bio-data-audit/
```

## 适合分享给谁

- 做代谢组学、微生物、食品发酵、生物统计或组学数据分析的研究人员
- 经常用 Excel/CSV 表格做实验数据整理的人
- 希望用 Codex 做数据分析，但担心 AI 黑箱处理数据的人
- 需要保留数据处理证据链、方便复核和汇报的课题组

## 注意事项

这个 skill 不替代专业统计判断，也不保证生物学解释一定正确。它的作用是强制 Codex 留下可复核的数据处理证据，让使用者知道每一步用了什么文件、什么参数、删掉了多少数据、生成了哪些结果，以及哪些结论仍需谨慎解释。

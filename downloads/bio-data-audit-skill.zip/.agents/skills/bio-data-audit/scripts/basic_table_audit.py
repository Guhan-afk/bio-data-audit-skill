#!/usr/bin/env python3

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import pandas as pd


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_sheet(value: str | None) -> str | int | None:
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return value


def read_table(path: Path, sheet: str | int | None = None) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path, sheet_name=0 if sheet is None else sheet)
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(path, sep="\t")
    raise ValueError(f"Unsupported file type: {suffix}")


def safe_records(frame: pd.DataFrame) -> list[dict[str, Any]]:
    return json.loads(frame.to_json(orient="records", force_ascii=False))


def summarize_table(df: pd.DataFrame, high_missing_threshold: float) -> dict[str, Any]:
    missing_count = df.isna().sum()
    missing_rate = missing_count / max(len(df), 1)
    numeric_cols = df.select_dtypes(include="number").columns.tolist()
    non_numeric_cols = [col for col in df.columns if col not in numeric_cols]
    constant_cols = [col for col in df.columns if df[col].nunique(dropna=False) <= 1]
    high_missing_cols = [
        col for col in df.columns if float(missing_rate[col]) >= high_missing_threshold
    ]

    top_missing = (
        pd.DataFrame(
            {
                "column": [str(col) for col in df.columns],
                "missing_count": missing_count.astype(int).values,
                "missing_rate": missing_rate.astype(float).values,
            }
        )
        .sort_values("missing_rate", ascending=False)
        .head(30)
    )

    numeric_summary = []
    if numeric_cols:
        numeric_summary = safe_records(
            df[numeric_cols]
            .describe()
            .T.reset_index()
            .rename(columns={"index": "column"})
            .head(50)
        )

    return {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "column_names": [str(col) for col in df.columns],
        "numeric_column_count": len(numeric_cols),
        "non_numeric_column_count": len(non_numeric_cols),
        "numeric_columns_preview": [str(col) for col in numeric_cols[:50]],
        "non_numeric_columns_preview": [str(col) for col in non_numeric_cols[:50]],
        "duplicate_rows": int(df.duplicated().sum()),
        "constant_columns": [str(col) for col in constant_cols[:100]],
        "high_missing_threshold": high_missing_threshold,
        "high_missing_columns": [str(col) for col in high_missing_cols[:100]],
        "top_missing_columns": safe_records(top_missing),
        "numeric_summary_preview": numeric_summary,
    }


def write_markdown_report(output_md: Path, file_info: dict[str, Any], summary: dict[str, Any]) -> None:
    lines = [
        "# 表格基础自检报告",
        "",
        "## 1. 文件信息",
        f"- 文件路径：`{file_info['path']}`",
        f"- 文件大小：{file_info['size_bytes']} bytes",
        f"- SHA256：`{file_info['sha256']}`",
    ]

    if file_info.get("sheet") is not None:
        lines.append(f"- Excel sheet：`{file_info['sheet']}`")

    lines.extend(
        [
            "",
            "## 2. 数据规模",
            f"- 行数：{summary['rows']}",
            f"- 列数：{summary['columns']}",
            f"- 数值列数量：{summary['numeric_column_count']}",
            f"- 非数值列数量：{summary['non_numeric_column_count']}",
            f"- 完全重复行数量：{summary['duplicate_rows']}",
            "",
            "## 3. 可能需要注意的问题",
        ]
    )

    if summary["constant_columns"]:
        lines.append("- 存在常量列：" + ", ".join(summary["constant_columns"][:20]))
    else:
        lines.append("- 未发现明显常量列。")

    threshold = float(summary["high_missing_threshold"])
    if summary["high_missing_columns"]:
        lines.append(
            f"- 存在缺失率 >= {threshold:.0%} 的列："
            + ", ".join(summary["high_missing_columns"][:20])
        )
    else:
        lines.append(f"- 未发现缺失率 >= {threshold:.0%} 的列。")

    lines.extend(["", "## 4. 缺失值最高的列"])
    for item in summary["top_missing_columns"][:20]:
        lines.append(
            f"- `{item['column']}`：缺失 {item['missing_count']}，"
            f"缺失率 {item['missing_rate']:.2%}"
        )

    lines.extend(["", "## 5. 数值列预览"])
    if summary["numeric_columns_preview"]:
        lines.extend(f"- `{col}`" for col in summary["numeric_columns_preview"][:30])
    else:
        lines.append("- 未检测到数值列。")

    lines.extend(["", "## 6. 非数值列预览"])
    if summary["non_numeric_columns_preview"]:
        lines.extend(f"- `{col}`" for col in summary["non_numeric_columns_preview"][:30])
    else:
        lines.append("- 未检测到非数值列。")

    lines.extend(
        [
            "",
            "## 7. 自检结论",
            "该报告只完成基础结构检查，不代表统计分析或生物学解释正确。"
            "后续仍需结合分组表、质控样本、过滤阈值、归一化方法和统计模型继续审查。",
        ]
    )

    output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_file", help="Input CSV, TSV, TXT, XLSX, or XLS file")
    parser.add_argument("--sheet", default=None, help="Excel sheet name or index")
    parser.add_argument("--outdir", default="audit", help="Output directory")
    parser.add_argument(
        "--high-missing-threshold",
        type=float,
        default=0.2,
        help="Missing-value rate used to flag highly missing columns",
    )
    args = parser.parse_args()

    input_path = Path(args.input_file)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    sheet = parse_sheet(args.sheet)
    df = read_table(input_path, sheet=sheet)

    file_info = {
        "path": str(input_path),
        "size_bytes": input_path.stat().st_size,
        "sha256": sha256_file(input_path),
        "sheet": sheet,
    }
    summary = summarize_table(df, high_missing_threshold=args.high_missing_threshold)

    json_out = outdir / f"{input_path.stem}_basic_audit.json"
    md_out = outdir / f"{input_path.stem}_basic_audit.md"

    json_out.write_text(
        json.dumps({"file_info": file_info, "summary": summary}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    write_markdown_report(md_out, file_info, summary)

    print(f"Audit JSON written to: {json_out}")
    print(f"Audit Markdown written to: {md_out}")


if __name__ == "__main__":
    main()

---
name: bio-data-audit
description: Create auditable, reproducible self-check records for biological, food fermentation, metabolomics, GC-MS, LC-MS, omics, Excel, CSV, TSV, statistical analysis, plotting, and report-generation tasks. Use when Codex processes biological tabular data, cleans or filters data, normalizes or transforms values, runs statistics, generates figures, or writes analysis reports. Do not use for chat-only explanations without data files.
---

# Bio Data Audit

Use this skill to make biological tabular data analysis externally auditable. The goal is not to expose hidden reasoning, but to leave evidence a researcher can inspect: input files, table dimensions, assumptions, filtering decisions, normalization methods, statistics, figure provenance, generated files, and remaining risks.

## Completion Criteria

Do not treat the task as complete until:

- Requested analysis outputs exist.
- Raw files under `data/raw/` have not been overwritten.
- `audit/analysis_plan.md`, `audit/processing_log.md`, and `audit/self_check_report.md` exist or have been updated.
- The self-check report lists input files, output files, major processing steps, parameters, row/column or feature/sample count changes, figure provenance, and risks.

## Required Project Layout

Use these paths unless the user or existing project structure clearly says otherwise:

- Raw data: `data/raw/`
- Metadata and sample grouping tables: `data/metadata/`
- Reproducible scripts: `scripts/`
- Processed tables and analysis results: `results/`
- Figures: `figures/`
- Human-readable summaries: `reports/`
- Plans, logs, and self-check reports: `audit/`

Create missing directories before analysis. Never overwrite raw data.

## Workflow

### 1. Plan First

Before the main analysis, write `audit/analysis_plan.md` with:

- Task goal
- Input files expected
- Output files expected
- Main processing steps
- Known assumptions
- Ambiguous points or questions

If ambiguity can change the scientific conclusion, pause and ask the user. If the task can reasonably proceed, continue and mark the assumption clearly in the audit report.

### 2. Run Basic Table Audit

For CSV, TSV, TXT, XLSX, or XLS files, run the bundled script when feasible:

```bash
python .agents/skills/bio-data-audit/scripts/basic_table_audit.py data/raw/example.xlsx --outdir audit
```

For Excel files, pass `--sheet` when a specific sheet is needed.

Use the generated JSON/Markdown audit summaries to avoid repeatedly loading large tables into context.

### 3. Log Processing

Record major operations in `audit/processing_log.md`. Include:

- Step number or timestamp
- Input file
- Operation
- Parameters
- Output file
- Row/column, feature/sample, or group count before and after
- Warnings or abnormal observations

Do not silently remove samples, rows, columns, peaks, metabolites, or features. Record every removal and the rule that caused it.

### 4. Analyze Reproducibly

Prefer scripts over manual spreadsheet edits. Save created or modified scripts under `scripts/`.

When applicable, report:

- Number of features/metabolites before and after filtering
- Number of samples per group
- Sample-name matching between data matrix and metadata table
- Missing-value threshold
- Imputation method
- Normalization method, such as TIC, total peak area, internal standard, PQN, z-score, Pareto, or autoscaling
- Transformation method, such as log2, log10, or log2(x + 1)
- Statistical test
- Multiple-testing correction method
- Fold-change calculation method
- Differential feature criteria
- Removed samples or suspicious outliers
- Whether QC samples were used
- Whether results are exploratory or confirmatory

### 5. Track Figures

For every generated figure, report:

- Figure filename
- Source data table
- Script or command used
- Main plotting parameters
- Whether labels, legends, units, and group names are clear
- Whether the figure is suitable for presentation
- Any risk of over-interpretation

## Required Table Checks

When reading Excel, CSV, or TSV files, check and report:

- File path
- File size
- File hash when feasible
- Sheet name for Excel
- Row and column counts
- Column names
- Numeric and non-numeric column counts
- Missing values
- Duplicate rows
- Duplicate feature IDs or metabolite names, if present
- Constant columns
- Highly missing columns
- Suspected sample columns
- Suspected annotation columns
- Whether sample metadata matches the data matrix

## Self-Check Report Template

Write `audit/self_check_report.md` in clear Chinese or in the user's requested language. Avoid unnecessary software jargon.

Use this structure:

```markdown
# 数据处理自检报告

## 1. 本次任务概述

## 2. 使用的原始数据

## 3. 数据结构检查

## 4. 数据处理流程

## 5. 关键参数记录

## 6. 输出文件清单

## 7. 结果可复核性

## 8. 风险与注意事项

## 9. 简明结论
```

The report should let the user answer:

- What raw files were used?
- What was the original size of each table?
- Which columns or samples were interpreted as sample names, feature names, groups, or numeric intensities?
- What rows, columns, peaks, samples, metabolites, or features were removed?
- What filtering, missing-value handling, normalization, transformation, and statistical methods were used?
- What intermediate and final files were created?
- Which figure came from which table and script?
- What possible risks or uncertain assumptions remain?
